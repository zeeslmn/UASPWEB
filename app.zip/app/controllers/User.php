<?php
session_start();
class User extends Controller {
    public function index(){
        $this->view('templates/headeruser');
        $this->view('user/index');
    
    }
    public function reservasi(){
        $this->view('user/reservasi');
     }
     public function logout(){
        $this->view('user/logout');
     }
}