<?php
session_start();
class Admin extends Controller {
    public function index(){
       $data['username'] = $_SESSION['username']; 
       $this->view('templates/header', $data);
       $this->view('admin/index', $data);
       $this->view('templates/footer');
    }
    public function logout(){
        $this->view('admin/logout');
     }
     public function addfood(){
        $data['username'] = $_SESSION['username'];
        $this->view('templates/header', $data);
        $this->view('admin/addfood');
        $this->view('templates/footer');
     }
     public function tambahmakanan(){
        $this->view('admin/tambahmakanan');
     }
     public function foodmenu(){
        $data['username'] = $_SESSION['username'];
        $this->view('templates/header', $data);
        $this->view('admin/foodmenu');
        $this->view('templates/footer');
     }
     public function reservasi(){
      $data['username'] = $_SESSION['username'];
      $this->view('templates/header', $data);
      $this->view('admin/reservasi');
      $this->view('templates/footer');
   }
}