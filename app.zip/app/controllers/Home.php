<?php
class Home extends Controller {
    public function index(){
       $this->view('home/index');
    }
    public function register(){
      $this->view('home/register');
   }
   public function cek_login(){
      $this->view('home/cek_login');
   }
   public function add_register(){
      $this->view('home/add_register');
   }
}