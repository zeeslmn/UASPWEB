<?php 
session_start();
include_once 'koneksi.php';
 
$username = $_POST ['username'];
$password = $_POST ['pass'];
 
 
// menyeleksi data user dengan username dan password yang sesuai
mysqli_query($koneksi,"INSERT INTO user VALUES('','$username', '$password', 'user')");
// menghitung jumlah data yang ditemukan
header('location:'.BASEURL.'/home');