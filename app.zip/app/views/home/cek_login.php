 <?php 
session_start();
include_once 'koneksi.php';
 
$username = $_POST ['username'];
$password = $_POST ['pass'];
 
 
// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"SELECT * FROM user WHERE username='$username' AND password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);
 
// cek apakah username dan password di temukan pada database
if($cek > 0){
 
	$data = mysqli_fetch_assoc($login);
 
	// cek jika user login sebagai admin
	if($data['level']=="admin"){
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "admin";
		$nama = $_SESSION['username'];
		// alihkan ke halaman dashboard admin
		header('location:'.BASEURL.'/admin/'.$nama.'');
    }
	// cek jika user login sebagai pegawai
	else if($data['level']=="user"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "user";
		$nama = $_SESSION['username'];
		// alihkan ke halaman dashboard pegawai
		header('location:'.BASEURL.'/user/'.$nama.'');
	}else{
 
		// alihkan ke halaman login kembali
		header("location:index.php");
	}	
}else{
	
}
 
?>