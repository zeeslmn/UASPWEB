<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js"> <!--<![endif]-->
<head>
    <title>MeatKing</title>

    <!-- meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">

    <!-- css -->
    <link rel="stylesheet" href="<?= BASEURL;?>/pengguna/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASEURL;?>/pengguna/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="<?= BASEURL;?>/pengguna/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= BASEURL;?>/pengguna/css/main.css">

    <!-- google font -->
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Kreon:300,400,700'>
    
    <!-- js -->
    <script src="<?= BASEURL;?>/pengguna/js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <script type="text/javascript">
                function scrollto(div){
                    $('html,body').animate({
                    scrollTop: $("#"+div).offset().top
                        },'slow');
                            }
                </script>
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="120" >
    <!--[if lt IE 7]>
        <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <div id="menu" class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header visible-xs">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><h2>Meat King</h2></a>
            </div><!-- navbar-header -->
        <div id="navbar" class="navbar-collapse collapse">
            <div class="hidden-xs" id="logo"><a onclick="scrollto('header')">
                <img src="<?= BASEURL;?>/pengguna/img/logo.png" alt="">
            </a></div>
            <ul class="nav navbar-nav navbar-right">
            
                <li><a onclick="scrollto('story')">Our Story</a></li>
                <li><a onclick="scrollto('facts')">A Facts</a></li>
                <li><a onclick="scrollto('food-menu')">Food Menu</a></li>
                
                <li><a onclick="scrollto('special-offser')">Special</a></li>
                <li><a onclick="scrollto('reservation')">Reservation</a></li>
                <li><a onclick="scrollto('chefs')">Chefs Team</a></li>

                
                
                <!--fix for scroll spy active menu element-->
                <li style="display:none;"><a href="#header"></a></li>

            </ul>

        </div><!--/.navbar-collapse -->
        </div><!-- container -->
    </div><!-- menu -->
