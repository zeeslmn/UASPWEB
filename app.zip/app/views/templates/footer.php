<div class="col-sm-12">
				<p class="back-link">&copy;UAS PWEB ©2021 by DZ </p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="<?= BASEURL;?>/administrator/js/jquery-1.11.1.min.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/bootstrap.min.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/chart.min.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/chart-data.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/easypiechart.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/easypiechart-data.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/bootstrap-datepicker.js"></script>
	<script src="<?= BASEURL;?>/administrator/js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>