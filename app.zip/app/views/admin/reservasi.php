<?php
include_once 'koneksi.php';


// menyeleksi data user dengan username dan password yang sesuai
$select2 = mysqli_query($koneksi,"SELECT * FROM reservasi ORDER BY id ASC");
?>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Forms</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Reservation</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
                <div class="table-responsive">
                <form role="form" action='<?= BASEURL;?>/user/index' method='POST'>
                    <table class="table table-striped table-hover">
                            <thead>
                                <tr class="bg-info">
                                <th scope="col">Id</th>
                                <th scope="col">Username</th>
                                <th scope="col">First Name</th>
                                <th scope="col">Last Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php 
                                    while ($data2 = mysqli_fetch_array($select2)){?>
                                    <th scope="row"><?php echo $data2['id'];?></th>
                                    <td><?php echo $data2['username'];?></td>
                                    <td><?php echo $data2['first'];?></td>
                                    <td><?php echo $data2['last'];?></td>
                                    <td><?php echo $data2['email'];?></td>
                                    <td><?php echo $data2['phone'];?></td>
                                    <td><?php echo $data2['address'];?></td>
                                </tr>
                                <?php }?>
                            </tbody>
                        </table>
                </div>
            </div>
            