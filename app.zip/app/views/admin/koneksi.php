<?php 
$koneksi = mysqli_connect("localhost","root","","multi_user");
	
?>