<?php
include_once 'koneksi.php';

// menyeleksi data user dengan username dan password yang sesuai
$select2 = mysqli_query($koneksi,"SELECT * FROM makanan ORDER BY id ASC");
?>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Forms</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Food Menu</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
                <div class="table-responsive">
                <form role="form" action='<?= BASEURL;?>/admin/ambilmakanan' method='POST'>
                    <table class="table table-striped table-hover">
                            <thead>
                                <tr class="bg-info">
                                <th scope="col">id</th>
                                <th scope="col">Food</th>
                                <th scope="col">Type of Food</th>
                                <th scope="col">Nutritional Info</th>
                                <th scope="col">Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php while ($data2 = mysqli_fetch_array($select2)){?>
                                    <th scope="row"><?php echo $data2['id'];?></th>
                                    <td><?php echo $data2['namamakanan'];?></td>
                                    <td><?php echo $data2['jenismakanan'];?></td>
                                    <td><?php echo $data2['infogizi'];?></td>
                                    <td><?php echo $data2['harga'];?></td>
                                </tr>
                                <?php }?>
                            </tbody>
                        </table>
                </div>
            </div>
            