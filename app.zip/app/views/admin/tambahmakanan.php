<?php 
session_start();
include_once 'koneksi.php';
 
$namamakanan = $_POST ['nama'];
$jenismakanan = $_POST ['jenis'];
$infogizi = $_POST ['info'];
$harga = $_POST ['harga'];
 
 
// menyeleksi data user dengan username dan password yang sesuai
mysqli_query($koneksi,"INSERT INTO makanan VALUES('','$namamakanan', '$jenismakanan', '$infogizi', '$harga')");
// menghitung jumlah data yang ditemukan
header('location:'.BASEURL.'/admin/addfood');