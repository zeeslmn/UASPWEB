<?php 
session_start();
include_once 'koneksi.php';
 
$username = $_POST ['username'];
$first = $_POST ['firstname'];
$last = $_POST ['lastname'];
$email = $_POST ['email'];
$phone = $_POST ['phone'];
$address = $_POST ['address'];
 
// menyeleksi data user dengan username dan password yang sesuai
mysqli_query($koneksi,"INSERT INTO reservasi VALUES('','$username', '$first', '$last', '$email', '$phone', '$address')");
// menghitung jumlah data yang ditemukan
header('location:'.BASEURL.'/user/index');