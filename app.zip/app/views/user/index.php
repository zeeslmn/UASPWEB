
    <div id="header">
        <div class="bg-overlay"></div>
        <div class="center text-center">
            <div class="banner">
                <h1 class="">Healthy Meat</h1>
            </div>
            <div class="subtitle"><h4>FIND YOUR HEALTHY MEAT HERE !</h4></div>
        </div>
        <div class="bottom text-center">
            <a id="scrollDownArrow" onclick="scrollto('special-offser')" ><i class="fa fa-chevron-down"></i></a>
        </div>
    </div>
    <!-- /#header -->

    <div id="story" class="light-wrapper">
        <section class="ss-style-top"></section>
        <div class="container inner">
            <h2 class="section-title text-center">Our Story</h2>
            <p class="lead main text-center">We're cooking delecious foods since 2021</p>
            <div class="row text-center story">
                <div class="col-sm-4">
                    <div class="col-wrapper">
                        <div class="icon-wrapper"> <i class="fa fa-anchor"></i> </div>
                        <h3>EST. 2021</h3>
                        <p>Siamo nati dal tocco dell'amore di un grande insegnante che ci vuole fare questo sito per i nostri voti dell'esame finale.</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="col-wrapper">
                        <div class="icon-wrapper"> <i class="fa  fa-cutlery"></i> </div>
                        <h3>Cooking Traditions</h3>
                        <p>Lavoriamo ogni strato della carne con cura e amore, e con un tocco gentile per farlo cucinare alla perfezione.</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="col-wrapper">
                        <div class="icon-wrapper"> <i class="fa fa-coffee"></i> </div>
                        <h3>Food Quality</h3>
                        <p>La qualità che forniamo è la più perfetta e offriamo prezzi molto bassi per una qualità molto alta.</p>
                    </div>
                </div>
            </div>
            <!-- /.services --> 
        </div>
        <!-- /.container -->
        <section class="ss-style-bottom"></section>
    </div><!-- #story -->


    <div id="facts" class="parallax parallax2 facts">
        <div class="container inner">
            <div class="row text-center services-3">
                <div class="col-sm-3">
                    <div class="col-wrapper">
                    <div class="icon-border bm10"></i> </div>
                    <h4>796518</h4>
                    <p>Meat Sold</p>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="col-wrapper">
                    <div class="icon-border bm10"></i> </div>
                    <h4>39472</h4>
                    <p>Satisfied</p>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="col-wrapper">
                    <div class="icon-border bm10"></i> </div>
                    <h4>2188764</h4>
                    <p>Cocktail Sold</p>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="col-wrapper">
                    <div class="icon-border bm10"></i> </div>
                    <h4>480523</h4>
                    <p>Customers Worldwide</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container --> 
    </div><!-- #facts -->




    <div id="food-menu" class="light-wrapper">
        <section class="ss-style-top"></section>
        <div class="container inner">
            <h2 class="section-title text-center">Menu</h2>
            <p class="lead main text-center">There is no sincerer love than the love of food!</p>

                        <div class="row">
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Chuck.jpeg" alt="Hot Drinks"></div>
                    <div class="menu-titles"><h1 class="">Chuck</h1></div>
                    <div class="menu-items ">
                        <ul>
                            <li>Cheap</li>
                            <li>Tough</li>
                            <li>Low and Slow</li>
                            <li>Smoke - Season Heavily - Marinate</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Flank.jpeg" alt="Ice Drinks"></div>
                    <div class="menu-titles"><h1 class="">Flank</h1></div>
                    <div class="menu-items ">
                        <ul>
                            <li>Expensive</li>
                            <li>Moderately Tender</li>
                            <li>High Heat Grilling</li>
                            <li>Heavy Seasoning</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Sirloin.jpeg" alt="Smoothies"></div>
                    <div class="menu-titles"><h1 class="">Sirloin</h1></div>
                    <div class="menu-items ">
                        <ul>
                            <li>Expensive</li>
                            <li>Moderately Tender</li>
                            <li>High Heat Grillinng</li>
                            <li>Heavy Seasoning</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Tbone.jpeg" alt="Deserts"></div>
                    <div class="menu-titles"><h1 class="">T-Bone</h1></div>
                    <div class="menu-items ">
                        <ul>
                            <li>Very Expensive</li>
                            <li>Tender</li>
                            <li>High Heat Grilling</li>
                            <li>Simple Seasoning</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Brisket.jpeg" alt="Hot Drinks"></div>
                    <div class="menu-titles"><h1 class="">Brisket</h1></div>
                    <div class="menu-items ">
                        <ul>
                            <li>Cheap</li>
                            <li>Tough</li>
                            <li>Low and Slow</li>
                            <li>Smoke - Season Heavily - Marinate</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Rump.jpeg" alt="Ice Drinks"></div>
                    <div class="menu-titles"><h1 class="">Rump</h1></div>
                    <div class="menu-items ">
                        <ul>
                        <li>Cheap</li>
                        <li>Tough</li>
                        <li>Low and Slow</li>
                        <li>Smoke - Season Heavily - Marinate</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/Ribeye.jpeg" alt="Smoothies"></div>
                    <div class="menu-titles"><h1 class="">Ribeye</h1></div>
                    <div class="menu-items ">
                        <ul>
                        <li>Very Expensive</li>
                        <li>Tender</li>
                        <li>High Heat Grilling</li>
                        <li>Simple Seasoning</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="menu-images "><img src="<?= BASEURL;?>/pengguna/img/menu/White.jpeg" alt="Deserts"></div>
                    <div class="menu-titles"><h1 class="">Beverages</h1></div>
                    <div class="menu-items ">
                        <ul>
                            <li>Eggnog</li>
                            <li>Irish Tequila</li>
                            <li>Frozen Margarita</li>
                            <li>Long Iceland Iced Tea</li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- /.container -->
        <section class="ss-style-bottom"></section>
    </div><!--/#food-menu-->




    <div id="special-offser" class="parallax pricing">
        <div class="container inner">

            <h2 class="section-title text-center">Special Offers</h2>
            <p class="lead main text-center">There is no sincerer love than the love of food!</p>
            
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    
                    <div class="pricing-item">
                        
                        <a href="#"><img class="img-responsive img-thumbnail" src="<?= BASEURL;?>/pengguna/img/dish/dish3.jpg" alt=""></a>
                        
                        <div class="pricing-item-details">
                            
                            <h3><a href="#">Fullblood Wagyu Sirloin</a></h3>
                            
                            <p>Small red potatoes - Asparagus - Olive oil - Butter - Salt - Pepper - Lemon pepper - Thyme - Garlic - Parsley - Parmesan.</p>
                            
                            
                            <div class="clearfix"></div>
                        </div>
                        <!--price tag-->
                        <span class="hot-tag br-red">$26</span>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    
                    <div class="pricing-item">
                        
                        <a href="#"><img class="img-responsive img-thumbnail" src="<?= BASEURL;?>/pengguna/img/dish/dish2.jpg" alt=""></a>
                        
                        <div class="pricing-item-details">
                            
                            <h3><a href="#">Texas T-Bone</a></h3>
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            
                           
                            <div class="clearfix"></div>
                        </div>
                        <!--price tag-->
                        <span class="hot-tag br-lblue">$37</span>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix visible-md"></div>
                <div class="col-md-6 col-sm-6">
                    
                    <div class="pricing-item">
                        
                        <a href="#"><img class="img-responsive img-thumbnail" src="<?= BASEURL;?>/pengguna/img/dish/dish4.jpg" alt=""></a>
                        
                        <div class="pricing-item-details">
                            
                            <h3><a href="#">BBQ Beef Brisket</a></h3>
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            
                           
                            <div class="clearfix"></div>
                        </div>
                        <!--price tag-->
                        <span class="hot-tag br-green">$54</span>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    
                    <div class="pricing-item">
                        
                        <a href="#"><img class="<?= BASEURL;?>/pengguna/img-responsive img-thumbnail" src="<?= BASEURL;?>/pengguna/img/menu/White.jpeg" alt=""></a>
                        
                        <div class="pricing-item-details">
                            
                            <h3><a href="#">White Russian</a></h3>
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            
                           
                            <div class="clearfix"></div>
                        </div>
                        <!--price tag-->
                        <span class="hot-tag br-red">$27</span>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container --> 
    </div><!-- /#special-offser -->




    <div id="reservation" class="light-wrapper">
        <section class="ss-style-top"></section>
        <div class="container inner">
            <h2 class="section-title text-center">Reservation</h2>
            <p class="lead main text-center">Reserve your table &amp; enjoy lorem Ipsum</p>
            <div class="row">
                <div class="col-md-6">
                        
                    <form class="form form-table" action='<?= BASEURL;?>/user/reservasi' method='POST' name="">
                        <div class="form-group">
                            <h4>Fill the form for table reservation (all fields required)</h4>
                        </div>
                        <div class="row">
                          <div class="col-lg-6 col-md-6 form-group">
                            <label class="sr-only" for="first_name1">first name</label>
                            <input class="form-control hint" type="text" id="first_name1" name="firstname" placeholder="First name" required="">
                          </div>
                          <div class="col-lg-6 col-md-6 form-group">
                            <label class="sr-only" for="last_name1">last name</label>
                            <input class="form-control hint" type="text" id="last_name1" name="lastname" placeholder="Last name" required="">
                          </div>
                        </div>
                        <div class="row">
                        <div class="col-lg-6 col-md-6 form-group">
                            <label class="sr-only" for="username">username</label>
                            <input class="form-control hint" type="text" id="username" name="username" placeholder="Enter Username" required="">
                          </div>
                          <div class="col-lg-6 col-md-6 form-group">
                            <label class="sr-only" for="email1">email</label>
                            <input class="form-control hint" type="email" id="email1" name="email" placeholder="Email@domain.com" required="">
                          </div>
                        </div>
                        <div class="row">
                        <div class="col-lg-6 col-md-6 form-group">
                            <label class="sr-only" for="phone1">Add Phone</label>
                            <input class="form-control hint" type="text" id="phone1" name="phone" placeholder="Phone" required="">
                          </div>
                          <div class="col-lg-6 col-md-6 form-group">
                            <label class="sr-only" for="phone1">address</label>
                            <input class="form-control hint" type="text" id="address" name="address" placeholder="Address" required="">
                          </div>
                        </div>
                
                        <div class="row">
                          <div class="col-lg-12 col-md-12">
                            <p>Thank you for your reservation.</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-lg-12 col-md-12">
                            <button type="submit" class="btn btn-danger btn-lg">Reserve!</button>
                          </div>
                        </div>
                      </form>
                </div><!-- col-md-6 -->
                <div class="col-md-5 col-md-offset-1">
                    
                    <h3><i class="fa fa-clock-o fa-fw"></i>Hours</h3>
                    <h4>Breakfast</h4>
                    <p>Mon to Fri: 7:30 AM - 11:30 AM<br>Sat &amp; Sun: 8:00 AM - 9:00 AM</p>
                    <h4>Lunch</h4>
                    <p>Mon to Fri: 12:00 PM - 5:00 PM</p>
                    <h4>Dinner</h4>
                    <p>Mon to Sat: 6:00 PM -  1:00 AM<br>Sun: 5:30 PM - 12:00 AM</p>

                    <h3><i class="fa fa-map-marker fa-fw"></i>Directions</h3>
                    <p>Argupuro Regency, Jember, East Java, Indonesian</p>

                    <h3><i class="fa fa-mobile fa-fw"></i>Contacts</h3>
                    <p>Email: <a href="mailto:derrelgeraryh@gmail.com">derrelgeraryh@gmail.com</a></p>
                    <p>Phone: +628123456789</p>

                </div><!-- col-md-6 -->
            </div>
            <!-- /.services --> 
        </div>
        <!-- /.container -->
        <section class="ss-style-bottom"></section>
    </div><!-- #reservation -->



    <div id="chefs" class="parallax pricing">
        <div class="container inner">

            <h2 class="section-title text-center">Our Chefs</h2>
            <p class="lead main text-center">There is no sincerer love than the love of food!</p>
            
            <div class="row text-center chefs">
                <div class="col-sm-4">
                    <div class="col-wrapper">
                        <div class="icon-wrapper">
                            <img src="<?= BASEURL;?>/pengguna/img/chefs/1.jpg">
                        </div>
                        <h3>Saransh Goila</h3>
                        <p>Vivamus sagittis lacuson augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum ultricies vehicula.</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="col-wrapper">
                        <div class="icon-wrapper">
                            <img src="<?= BASEURL;?>/pengguna/img/chefs/3.jpg">
                        </div>
                        <h3>Jane Doe</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cum sociis natoque penatibus et magnis dis parturient monte nascetur ultricies vehicula. </p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="col-wrapper">
                        <div class="icon-wrapper">
                            <img src="<?= BASEURL;?>/pengguna/img/chefs/2.jpg">
                        </div>
                        <h3>Anton Mosimann</h3>
                        <p>Curabitur blandit matti tempus porttitor. Donec id elit non mi porta ut gravida at eget metus. Consectetur adipiscing elit ultricies vehicula.</p>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container --> 
    </div><!-- /#chefs -->


    <footer id="footer" class="dark-wrapper">
        <section class="ss-style-top"></section>
        <div class="container inner">
            <div class="row">
                <div class="col-sm-6">
                    &copy; UAS PWEB ©2021 by DZ 
                    <form class="form-inline my-2 my-lg-0">
            <a class="btn btn-danger btn-sm text-dark " href='<?= BASEURL;?>/user/logout'>Sign Out</a>
            </form>
                </div>
                <div class="col-sm-6">
                    <div class="social-bar">
                        
                        <a href="#" class="fa fa-instagram tooltipped" title=""></a>
                        <a href="#" class="fa fa-youtube-square tooltipped" title=""></a>
                        <a href="#" class="fa fa-facebook-square tooltipped" title=""></a>
                        <a href="#" class="fa fa-pinterest-square tooltipped" title=""></a>
                        <a href="#" class="fa fa-google-plus-square tooltipped" title=""></a><br><br>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container -->
    </footer>

    <script src="<?= BASEURL;?>/pengguna/js/jquery-2.1.3.min.js"></script>
    <script src="<?= BASEURL;?>/pengguna/js/jquery.actual.min.js"></script>
    <script src="<?= BASEURL;?>/pengguna/js/jquery.scrollTo.min.js"></script>
    <script src="<?= BASEURL;?>/pengguna/js/bootstrap.min.js"></script>
    <script src="<?= BASEURL;?>/pengguna/js/main.js"></script>
    <script>function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>
</body>
</html>