<?php

define('BASEURL','http://localhost/uaspweb/public');
define('BASEURM','http://localhost/uaspweb/app');